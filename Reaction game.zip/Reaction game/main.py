import pygame,time,random
pygame.init()

while True:
    rounds = input('Wie viele Runden möchtest du spielen?')
    try:
        rounds = int(rounds)
        if rounds <= 0: print('Ungültige Zahl')
        else:break
    except: print('Ungültige Zahl')

screen = pygame.display.set_mode((1500,800),pygame.FULLSCREEN)
circlecount = 0
times = []
circlepos = (random.randint(0,screen.get_width()),random.randint(0,screen.get_height()))
circlecol = (random.randint(50,255),random.randint(50,255),random.randint(50,255))
pygame.display.set_caption(f'Reaktionsspiel, {rounds} Runden')
text = pygame.font.SysFont('arial', 30).render('START', True, (0, 255, 255))
br = False

while not br:
    screen.fill((0,0,0))
    for event in pygame.event.get():
        if event.type == pygame.QUIT: quit()
    if pygame.mouse.get_pos()[0] in range(int(screen.get_width() / 2 - text.get_width() / 2 - 10),int(screen.get_width() / 2 + text.get_width() / 2 + 10)) \
            and pygame.mouse.get_pos()[1] in range(int(screen.get_height() / 2 - text.get_height() / 2 - 5),int(screen.get_height() / 2 +text.get_height() / 2 + 5)):
        text = pygame.font.SysFont('arial',35).render('START',True,(0,255,255))
        if pygame.mouse.get_pressed(3)[0]: break
    else:text = pygame.font.SysFont('arial',30).render('START',True,(0,255,255))
    pygame.draw.rect(screen,(255,0,0), pygame.Rect(screen.get_width()/2-text.get_width()/2-10, screen.get_height()/2-text.get_height()/2-5, text.get_width()+20,text.get_height()+10),3)
    screen.blit(text,(screen.get_width()/2-text.get_width()/2,screen.get_height()/2-text.get_height()/2))
    pygame.display.flip()
    time.sleep(0.01)

starttime = time.time()
while True:
    screen.fill((0,0,0))
    screen.blit(pygame.image.load('Pausebutton.png'),(screen.get_width()-120,20))
    for event in pygame.event.get():
        if event.type == pygame.QUIT: quit()
    pygame.draw.circle(screen,circlecol,circlepos,20,3)
    if pygame.Rect((circlepos[0]-20,circlepos[1]-20),(40,40)).colliderect(pygame.Rect(pygame.mouse.get_pos(),(1,1))) and pygame.mouse.get_pressed(3)[0]:
        times.append(time.time()-starttime)
        starttime = time.time()
        circlepos = (random.randint(0,screen.get_width()),random.randint(0,screen.get_height()))
        circlecol = (random.randint(50,255),random.randint(50,255),random.randint(50,255))
        circlecount += 1
    if circlecount >= rounds: break
    pygame.display.flip()

pygame.display.quit()

short = str(round(sum(times),4))
durchschnitt = round(float(short)/len(times),4)
pts = round(len(times)/sum(times)*100,2)
if pts <= 50: rang = 'schlecht'
elif pts <= 100: rang = 'Anfänger'
elif pts <= 120: rang = 'Fortgeschritten'
elif pts <= 150: rang = 'Profi'
elif pts <= 170: rang = 'König'
elif pts <= 200: rang = 'Gott'
else: rang = 'Hacker! -_-'
pts = str(pts)

print('╔═════════════════════════╗')
print('║ Checkpoints:            ║')
for i in times:
    short = str(round(i,3))
    print('║',str(times.index(i)+1)+' '*(4-len(str(times.index(i)+1)))+short+' '*(7-len(short))+'sek          ║')
short = str(round(sum(times),4))
print('╟─────────────────────────╢')
print('║                         ║')
print('║ Gesamt:'+' '*(16-len(short))+short,'║')
print('║ Durchschnitt:'+' '*(10-len(str(durchschnitt)))+str(durchschnitt),'║')
print('║                         ║')
print('║ Punkte:'+' '*(16-len(pts))+pts,'║')
print('║ Rang:'+' '*(18-len(rang))+rang,'║')
print('╚═════════════════════════╝')
